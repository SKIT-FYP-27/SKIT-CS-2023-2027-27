# Week 1 — Kashish Soni

**Sprint:** S1 – Requirement Analysis, Data Study & Project Setup
**Week 1:** 10/08/2026 – 16/08/2026
**User story (Form-2):** [S1] Manual workbook study, master data & DB design — *Week 1 part only*

## Your Week 1 work

1. **Map every sheet, column and calculation of the department's manual workbooks** — which numbers
   are Excel formulas, which are typed by hand, and the exact rule behind each one
   (`MANUAL_WORKBOOK_MAP.md`). This is the ground truth the system must reproduce.
2. **List the problems** found in the manual workbooks and the **questions for the department**.
3. **Formula-listing script** that prints every formula pattern of a workbook, sheet by sheet —
   the tool you use to check the map.

## Files in this zip

Everything under `repo/` goes into the repository at the same path.

| Path | What it is |
|---|---|
| `docs/data-study/MANUAL_WORKBOOK_MAP.md` | Sheet-by-sheet map (Annexures I–V, per-branch TR sheets, II Sem workbook), calculations C1–C7, problems P1–P6, questions |
| `analytics/scripts/explore/list_formulas.py` | Formula-listing script (flags `#REF!` errors) |
| `analytics/requirements.txt` | `openpyxl` (same file as in Katyayini's zip) |

## How to check it works

Put the manual workbooks in `data/` (git-ignored — never commit them). Save `.xls` files as `.xlsx` first.

```bash
pip install -r analytics/requirements.txt
python analytics/scripts/explore/list_formulas.py "data/I Sem  2024-25 TR Result Analysis.xlsx"
```

Expected: `Over all` shows **10 formulas with #REF!** (problem P1); `Section wise` has 2 patterns
(`=H6+I6+J6`, `=K6*100/F6`); `Rank Holder's Name` has no formulas.

## Push

Wait until Harsh has created the repository, then:

- Branch `docs/manual-workbook-map` → PR:
  1. `docs(analytics): manual workbook sheet and calculation map`
  2. `feat(analytics): formula listing script for manual workbooks`

## Done when

- [ ] Map reviewed by the team; the questions sent to the mentor/department
- [ ] Script runs on every manual workbook in `data/`
- [ ] PR merged; no real student data in the repository

**For the weekly report:** Mapped every sheet, column and calculation of the department's manual
result-analysis workbooks (Annexures I–V and branch TR sheets), recorded the problems found in them,
and wrote a script that lists all workbook formulas.
